<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'ข้อมูลไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง',
    'throttle' => 'คุณลงชื่อเข้าใช้งานมากเกินไป. กรุณาใช้งานอีกใน  :seconds seconds.',

];
